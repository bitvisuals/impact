var app = app || {};

$(function() {
    app.init();
});